import java.util.ArrayList;

public class FileAttente<E> {
    // private String nomFile; // never used
    private static int nbEntreesTotal = 0;
    private ArrayList<E> contenu;

    public FileAttente() {
        contenu = new ArrayList<E>();
    }

    public void entre(E e) {
        contenu.add(e);
        nbEntreesTotal++;
    }

    public E sort() {
        E e = null;
        if (!contenu.isEmpty()) {
            e = contenu.get(0);
            contenu.remove(0); // attention, efficacité catastrophique, ne surtout pas faire "en vrai"
        }
        return e;
    }

    public int nbElements() {
        return contenu.size();
    }

    public boolean estVide() {
        return contenu.isEmpty();
    }

    public String toString() {
        return "" + descriptionContenu();
    }

    private String descriptionContenu() {
        String resultat = "";
        for (E e : this.contenu)
            resultat += e + " ";
        return resultat;
    }

    public static int getNbEntreesTotal() {
        return FileAttente.nbEntreesTotal;// ou nbEntreesTotal mais déconseillé
    }

    public static <T> boolean comparaisonContenu(FileAttente<T> f1, FileAttente<T> f2) {
        return f1.equals(f2); // il faut donc définir equals
    }

    public boolean comparaisonAvec(FileAttente<E> f) {
        return this.equals(f);
    }

    public <T> boolean comparaisonTailleAvec(FileAttente<T> f){
        return this.nbElements()==f.nbElements();
    }

    @Override
    public boolean equals(Object o) { // normalement il faut redéfinir aussi la méthode hashcode
        if (!(o instanceof FileAttente)) {
            return false;
        } else {
            // même contenu : mêmes objets dans le même ordre
            return this.contenu.equals(((FileAttente) o).contenu);
        }
    }

    public static void main(String[] args){
        Personne p1=new Personne("p1");
        Personne p2=new Personne("p2");
        Rectangle r1=new Rectangle();
        Rectangle r2=new Rectangle();

        FileAttente<Personne> fileP = new FileAttente<>();
        FileAttente<Personne> filePbis = new FileAttente<>();
		FileAttente<Rectangle> fileR = new FileAttente<>();
		
		fileP.entre(p1);
		fileP.entre(p2);
		System.out.println(fileP);

        filePbis.entre(p1);
		filePbis.entre(p2);
		System.out.println(filePbis);

		fileR.entre(r1);
		fileR.entre(r2);
		System.out.println(fileR);

		System.out.println(fileP.comparaisonAvec(filePbis));
		System.out.println(FileAttente.comparaisonContenu(fileP, filePbis));
		
    }
}
