public class PaireHomogene <A> extends Paire<A,A> {
    public PaireHomogene(){}
    
    public PaireHomogene(A a1, A a2){
        super(a1, a2);
    } 

    public static void main(String[] args) {
      PaireHomogene<Integer> phi =new PaireHomogene<>(2, 3);
      System.out.println(phi);  
    }
}
