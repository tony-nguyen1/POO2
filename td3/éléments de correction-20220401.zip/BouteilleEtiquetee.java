public class BouteilleEtiquetee<TE> extends Bouteille {
    TE etiquette;

    public BouteilleEtiquetee(TE etiquette){
        super();
        this.etiquette=etiquette;
    }
    

    @Override
    public String toString() {
        return "BouteilleEtiquetee [etiquette=" + etiquette + "]";
    }


    public static void main(String[] args) {
        Etiquette etiquette=new Etiquette(0, "nomProducteur", "adresseProducteur", "un liquide", 0.75f);
        BouteilleEtiquetee<Etiquette> bouteille=new BouteilleEtiquetee<>(etiquette);
        System.out.println(bouteille);
    }
}
