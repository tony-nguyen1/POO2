public class Bouteille {
    public String toString(){
        return "Bouteille";
    }    
}
