import java.time.LocalDateTime;

public class EntreeAgenda extends Paire<LocalDateTime, String> {
    public EntreeAgenda(LocalDateTime d, String s){
        super(d,s);
    }

    public static void main(String[] args) {
        EntreeAgenda e=new EntreeAgenda(LocalDateTime.now(), "travail intensif");
        System.out.println(e);
    }
}
