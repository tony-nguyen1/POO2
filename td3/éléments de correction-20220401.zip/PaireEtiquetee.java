public class PaireEtiquetee<A, B, E> extends Paire<A, B> {
    private E etiquette;

    public PaireEtiquetee(A f, B s, E e) {
        super(f, s);
        this.etiquette = e;
    }

    public String toString() {
        return super.toString() + " avec etiquette " + etiquette;
    }

    public static void main(String[] args){
        PaireEtiquetee<Integer, Integer, Integer> piii=new PaireEtiquetee<>(1, 1, 1);
        PaireEtiquetee<Integer, Integer, String> piis=new PaireEtiquetee<>(1, 1, "hop");
        System.out.println(piii);
        System.out.println(piis);
    }
}