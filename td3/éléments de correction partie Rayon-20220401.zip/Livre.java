public class Livre extends ProduitEtiquete {
    public Livre(String etiquette){
        super(etiquette);
    }
}
