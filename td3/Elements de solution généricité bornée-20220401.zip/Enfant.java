package genericiteBornee;

public class Enfant extends Personne {

	public Enfant() {
		// TODO Auto-generated constructor stub
	}

	public Enfant(String nom, String prenom, boolean inv, int a) {
		super(nom, prenom, inv, a);
		// TODO Auto-generated constructor stub
	}

}
