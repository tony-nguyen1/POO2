package genericiteBornee;

public interface ObjetAvecEtiquette {
	String etiquette();
}
