package genericiteBornee;

public interface Invitable {
	public boolean estInvite();
}
